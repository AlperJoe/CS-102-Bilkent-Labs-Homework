public class Term extends Document {

    public Term(String text){

        int numberOfAppearance=0;
    }
    private int count;
    private String word;

    public void incrementCount(){
        count += 1;
    }

    //getters
    public int getCount(){return count;}
    public String getWord(){return word;}

    //setters
    public void setCount(){this.count=count;}
    public void setWord(){this.word = word;}

}
