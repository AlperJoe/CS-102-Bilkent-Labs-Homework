import jdk.swing.interop.SwingInterOpUtils;

import java.util.Scanner;
public class DocumentAnalyzer {


    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("Enter the number of documents:");
        int numberOfDoc = scan.nextInt();

        Document object = new Document();

        Document[] filenames = new Document[numberOfDoc];

        for(int i = 1; i <= numberOfDoc; i ++) {
            System.out.println("Enter the name of the document" + i + ":");
            String nameDoc = scan.next();
            Document nameOfDoc = new Document(nameDoc);
            filenames[i] = nameOfDoc;
        }


        System.out.println("Enter an option (enter x to quit):");
        int option = scan.nextInt();

        if(option == 1){

            //displaying the frequency of a user entered word in a given document
            System.out.println("Enter the word which you want to find the frequency:");
            String userInput = scan.next();
            object.getFrequency(userInput);
        }
        else if (option == 2){
            //finding the most frequent terms in each document

        }
        else if(option == 3){
            System.out.println("Enter the word which you want to calculate tf-idf:");
            String userInput = scan.next();
            

        }
    }
}
