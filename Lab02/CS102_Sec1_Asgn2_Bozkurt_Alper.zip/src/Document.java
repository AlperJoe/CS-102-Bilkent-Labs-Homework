
public class Document{

    //store file name of document
    private String fileName;

    //a private array of Term
    private Term[] termList;

    //A default constructor
    public Document() {}

    //A constructor which takes a string fileName and sets the filename of the document.
    // The array is initialized.
    public Document(String fileName) {
        this.fileName = fileName;
        termList = new Term[10000];
        Term object;
    }

    //This method should read the document and fill the array of Term objects
    // based the words in the document and their number of appearance.
    public void processDocument(){
        for(int i = 0; i < termList.length; i++){
            for(int j = 1; i <= termList.length; j++){

            }
        }
    }
    //This method should return the number of appearance of a given word.
    public int getCount(String word) {
        int counter = 0;
        for (int i = 0; i < termList.length; i++) {
            if(termList[i].equals(word)){
                counter ++;
            }
        }
        return counter;
    }
    public int getFrequency(String word){
        return getCount(word)/ termList.length;
    }
    //getters
    public String getFileName(){return fileName;}
    public Term[] getTermList(){return termList;}

    //setters
    public void setFileName(){this.fileName = fileName;}
    public void setTermList(){this.termList = termList;}
}